const socialIconsArr = [
  {
    icon_id: 'facebook',
    href: 'https://www.facebook.com',
  },
  {
    icon_id: 'linkedin',
    href: 'https://www.linkedin.com',
  },
  {
    icon_id: 'twitter',
    href: 'https://ads.twitter.com',
  },
  {
    icon_id: 'youtube',
    href: 'https://www.youtube.com',
  },
]

export default socialIconsArr
